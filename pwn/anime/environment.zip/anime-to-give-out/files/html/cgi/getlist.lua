print(cgi.getdata())
