print(cgi.setdata(cgi.getdata()..cgi.postbody().."\n"))
